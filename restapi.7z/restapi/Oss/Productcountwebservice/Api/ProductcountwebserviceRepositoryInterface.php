<?php
namespace Oss\Productcountwebservice\Api;
/**
 * Interface ProductcountwebserviceRepositoryInterface
 * @package Oss\Productcountwebservice\Api
 */
interface ProductcountwebserviceRepositoryInterface
{
    /**
     * @return int
     */
    public function getCatalogProductCount();
    /**
     * @param int $categoryId
     *
     * @return mixed
     */
    public function getCategoryProductCount($categoryId);
}