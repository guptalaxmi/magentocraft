function clearText(thefield) {
  if (thefield.defaultValue==thefield.value) { thefield.value = "" }
} 
function replaceText(thefield) {
  if (thefield.value=="") { thefield.value = thefield.defaultValue }
}

function popup_show(g)
{
  document.getElementById(g).style.display='block';
  
}
function popup_hide(g)
{
  document.getElementById(g).style.display='none';  
} 