<?php 
/**
 * Template Name: Test pa
 * Login Page Template.
 * @author Ahmad Awais
 * @since 1.0.0e
 */
get_header(); 
?>

<style>
#popup {
    width: 100%;
    height: 100%;
    opacity: 0.95;
    top: 0;
    left: 0;
    display: none;
    position: fixed;
    overflow: auto;
	background-color: #313131;
}
div#popupContact {
    position: absolute;
    left: 50%;
    top: 55%;
    margin-left: -202px;
    font-family: 'Raleway', sans-serif;
}
form {
    max-width: 300px;
    min-width: 250px;
    padding: 10px 50px;
    border: 2px solid gray;
    border-radius: 10px;
    font-family: raleway;
    background-color: white;
}
input[type=text] {
    width: 82%;
    padding: 10px;
    margin-top: 30px;
    border: 1px solid #ccc;
    padding-left: 40px;
    font-size: 16px;
    font-family: raleway;
}
a#close {
    position: absolute;
        right: 5px;
    top: 2px;
    cursor: pointer;
}
</style>
<script>
jQuery(document).ready(function(){
jQuery("#frmaccesscode").submit(function(){
	jQuery("#success_msg").html('');
	jQuery("#feedback_msg1").html('');
		if(jQuery("#accesscode").val()==''){
			jQuery("#error_msg").html("<span style='color:green'>Please enter Access Code</span>");
			//alert("Please enter Access Code");
			return false;
		}				
		
		var data = {
			'action': 'check_accesscode',
			'codeData': jQuery("#frmaccesscode").serialize()
		};
		jQuery.ajax({
			type: "post",
			dataType: "json",
			url: "<?php echo admin_url('admin-ajax.php'); ?>",
			data: data,
			success: function(msg){
				var urlData=msg.url;
				if(msg.status=='1'){	
                  jQuery("#success_msg").html(urlData);
					jQuery("#success_msg").show();				
					jQuery("#error_msg").html("<span style='color:green'>Thanks for Submition</span>");
					jQuery("#error_msg").show();
					jQuery("#frmaccesscode input[type=text],#frmaccesscode textarea").val('');
				}else{				
                    jQuery("#success_msg").html(urlData);
					jQuery("#success_msg").show();
					
					jQuery("#error_msg").html("<span style='color:red'>Access code not valid</span>");
					jQuery("#error_msg").show();										
				}
			}
		});
		return false;
	});
	
	jQuery( "a#close" ).click(function() {    
       jQuery('#popup').css("visibility", "hidden"); 
       jQuery('#popup').css("opacity", 0);
    });
	});
</script>

<?php
if(is_user_logged_in()){
?>
<div class="form_cl" id="popup" style="display: block;">
<div id="popupContact">
    	<form action="" id="frmaccesscode" method="post" >
		  <a  id="close">close</a>
			<div>
			    <input type="text" name="accesscode" id="accesscode">
			</div>
			<div>
			   <div id="error_msg"></div> 	<div id="success_msg"></div>
   			</div>
			 <div>
					<input type="submit" name="submit" value="Submit" style="margin-top:10px;">
			 </div>
		</form>
</div>
</div>
<?php }	 ?>	
<!-- Popup -->
 <?php get_footer(); ?>
 <?php
/*
$orderId=23;$itemId=3;
$order = new WC_Order($orderId);
foreach($order->get_items() as $item){
	$orderItemID = $item->get_id();
	if($itemId==$orderItemID){
	//  $url = get_permalink( $item['product_id'] ) ;
	}
}
*/

?>
