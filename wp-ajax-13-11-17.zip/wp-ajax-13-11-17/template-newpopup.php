<?php 
/**
 * AccessCode Popup Page Template.
 * @author Ahmad Awais
 * @since 1.0.0e
 */
 /*
Template Name: New popup Page Template
*/
 //get_header(); 
?>
<!-- header start-->
<!DOCTYPE html>
<html class="no-js <?php echo esc_attr( $lol_responsive_check . ' ' . $lol_sticky_check . ' ' . $lol_is_transparent . ' ' . $lol_has_not_title . ' ' . $lol_blog_layout . ' ' . $lol_page_margin_top . ' ' . $lol_parallax_mobile ); ?>" <?php language_attributes();?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<?php if ( get_option( 'lol_check_responsive' ) == 'true' ) { ?>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
	<?php } ?>
	<title><?php wp_title( '|', true, 'right' ); ?></title>
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php // if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' ); ?>
	<link rel="alternate" title="<?php printf( esc_html__( '%s RSS Feed', 'lollum' ), get_bloginfo( 'name' ) ); ?>" href="<?php bloginfo( 'rss2_url' ); ?>">
	<link rel="alternate" title="<?php printf( esc_html__( '%s Atom Feed', 'lollum' ), get_bloginfo( 'name' ) ); ?>" href="<?php bloginfo( 'atom_url' ); ?>">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php if ( get_option( 'lol_custom_favicon' ) ) { ?>
		<link rel="shortcut icon" href="<?php echo esc_url( get_option( 'lol_custom_favicon' ) ); ?>">
	<?php } ?>
	<script>document.documentElement.className += " js";</script>
	<!-- BEGIN WP -->
	<?php wp_head(); ?>
	<!-- END WP -->
</head>
<body <?php body_class();?>>
<?php
	/**
	* llm_mobile_menu hook
	*
	* @hooked llm_mobile_menu - 10
	*/
	//do_action( 'llm_mobile_menu' );
?>

<?php
	/**
	* llm_sidebar_cart hook
	*
	* @hooked llm_sidebar_cart - 10
	*/
	//do_action( 'llm_sidebar_cart' );
?>

<?php
	/**
	* llm_output_content_wrapper hook
	*
	* @hooked llm_output_content_wrapper - 10
	*/
	//do_action( 'llm_output_content_wrapper' );
?>

<?php
	/**
	* llm_header hook
	*
	* @hooked llm_branding - 10
	* @hooked llm_submenu - 20
	*/
	//do_action( 'llm_header' );
?>
<!-- header start-->


<!--body content-->
<div class="logo" align="center">
                    		<a href="http://localhost/museumofknowledge"><img src="http://www.museumofknowledge.com/wp-content/uploads/2016/12/MOK-logo-low-resolution-VERSION-2.jpg" class="img-responsive" alt="img-rounded" width="344" height="276" align="center"></a>

</div>
<div class="navbar navbar-inverse" role="navigation">
 	 	<div class="container">
 				<div class="navbar-header">
        				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                		<span class="sr-only">Toggle Navigation</span>		
						<span class="icon-bar"></span>	                
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
 				</button>
 				<a class="navbar-brand" href="#">WELCOME test55 test</a>
					</div>            
 			              <div class="collapse navbar-collapse collapse">
                      				<ul class="nav navbar-nav navbar-right">
                      					<li class="active"><a href="#" lass="btn btn-lg btn-success" data-toggle="modal" data-target="#basicModal">DASHBOARD</a></li>
											
                                        
	                                            		<li class=""><a href="#"> </a></li>
                            <li class="dropdown">        
                             <a href="#" class="dropdown-toggle" data-toggle="dropdown">HISTORY<b class="caret"></b></a>
                                           <ul class="dropdown-menu">
                                            	<li class="dropdown-header"><a href="#">RECENT PURCHASED</a></li>
                                            	<li class="dropdown-header"><a href="#">SAVE DRAFTS</a></li>
												<li class="dropdown-header"><a href="#">SUBMITTED EXERCISES</a></li> 
                                                <li class="dropdown-header"><a href="#">MARKED EXERCISES</a></li>
                                                <li class="dropdown-header"><a href="#">PAST PURCHASES</a></li>   
                                                       
                                                       		</ul>
                                                       </li>
            
                                                        			
                                             
                     		<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">ACCOUNT SETTINGS<b class="caret"></b></a>
                                		<ul class="dropdown-menu">
											<li class="dropdown-header"><a href="#">SECURITY</a></li>
                                            <li class="dropdown-header"><a href="#">PERSONAL INFORMATION</a></li>
											<li class="dropdown-header"><a href="#">SIGN OUT</a></li>                                                                        
                                                                       
                                                                
                                                  </ul>  	
                                      	                                                 	
                                       		</li>                 
                                                                                      	
                       		</ul></div>
  						</div>  
</div>
<div class="jumbotron" align="justify">
				<h4>Welcome to Museum of Knowledge</h4>	
				<h4>you can choose different module</h4>
				<h4>in our course outline</h4>
				<br>
				<h4>Course offer, Sample 1, Sample 2, Sample 3</h4>
				<br>
				<h4>Add more Description here optional the background</h4>
				<h4>will automatically adjust</h4>	
		
</div>
<div class="navbar navbar-inverse navbar-fixed-bottom role=" navigation"="">
		<div class="container">
      	<div class="navbar-text pull-left">  
        <p>©Museum of Knowledge</p>
        
        </div>
  </div>
</div>
<!--body content-->
<!-- footer start-->
<footer id="popupfooter" class="<?php echo esc_attr( get_option( 'lol_footer_style' ) ); ?>" role="contentinfo">
 <?php
		/**
		* llm_footer hook
		* @hooked llm_footer - 10
		*/
		//do_action( 'llm_footer' );
?>	
</footer>
<?php if ( get_option( 'lol_footer_bottom_check' )  == 'true' ) : ?>
	<!-- BEGIN #footer-bottom -->
	<div id="footer-bottom" class="<?php echo esc_attr( get_option( 'lol_footer_style' ) ); ?>">
		<?php
			/**
			* llm_footer_bottom hook
			* @hooked llm_footer_bottom - 10
			*/
			//do_action( 'llm_footer_bottom' );
		?>
	</div>
	<!-- END #footer-bottom -->
<?php endif; ?>
<?php if ( get_option( 'lol_check_custom_rating_system' ) === 'true' ) : 
		/**
		* llm_reviews_popup hook
		* @hooked llm_reviews_popup - 10
		*/
		//do_action( 'llm_reviews_popup' );
	 endif; ?>
<?php //do_action( 'lollum_woocommerce_store_notice' ); ?>
<?php
	/**
	* llm_output_content_wrapper_end hook
	* @hooked llm_output_content_wrapper_end - 10
	*/
	do_action( 'llm_output_content_wrapper_end' );
?>
<?php
 /*if ( $lol_g_analitycs = get_option( 'lol_google_analytics' ) ) {
	//echo stripslashes( $lol_g_analitycs );
}*/ ?>
<?php wp_footer(); ?>
</body>
</html>
<!--footer end-->
	
	
<script>
jQuery(document).ready(function(){	
jQuery(window).load(function(){        
   jQuery('#myModal').modal('show');
}); 
	
jQuery("form#frmaccesscode").submit(function(){
	jQuery("#success_msg").html('');
	jQuery("#feedback_msg1").html('');
		if(jQuery("#accesscode").val()==''){
			jQuery("#error_msg").html("<span style='color:red'>Please Enter Access Code.</span>");
			//alert("Please enter Access Code");
			return false;
		}				
		
		var data = {
			'action': 'check_accesscode',
			'codeData': jQuery("#frmaccesscode").serialize()
		};
		jQuery.ajax({
			type: "post",
			dataType: "json",
			url: "<?php echo admin_url('admin-ajax.php'); ?>",
			data: data,
			success: function(msg){
				
				var urlData=msg.url;
				
				if(msg.status=='1'){	
					
                    jQuery("#error_msg").html("<span style='color:red'>Thanks For Submition.</span>");
					jQuery("#error_msg").show();
					jQuery("#frmaccesscode input[type=text],#frmaccesscode textarea").val('');					
					 setTimeout(function(){window.location.href= urlData; } , 1000);
					
				}else{			
					
                    jQuery("#error_msg").html("<span style='color:red'>Please Enter Valid Access Code.</span>");
					jQuery("#error_msg").show();	
					
				}
			}
		});
		return false;
	});
	
	jQuery( "a#close" ).click(function() {    
       jQuery('#popup').css("visibility", "hidden"); 
       jQuery('#popup').css("opacity", 0);
    });
	});
</script>

<!-- Popup -->

<style>
@media (min-width: 768px)
bootstrap.min.css?ver=2.0.0:5
.modal-dialog {
    width: 600px;
    margin: 149px auto;
}
	
div.bottom-popup{
		 padding: 15px;  
		text-align: right;  
		border-top: 1px solid #e5e5e5;
}
.btn-resend,input[type=reset] {
    color: #fff;
    background-color: #3d4045;
    border-color: #3d4045;
}
	
div.modal-header img{
 width: 37%;
}
	
.jumbotron {
    background: #efefef url(http://www.museumofknowledge.com/wp-content/uploads/2017/11/img1.jpg) no-repeat center center fixed;
    font-color: solid white;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
}
	
.jumbotron {
  padding: 30px 15px;
  margin-bottom: 30px;
  color: inherit;
  background-color: #eee;
}
.jumbotron h1,
.jumbotron .h1 {
  color: inherit;
}
.jumbotron p {
  margin-bottom: 15px;
  font-size: 21px;
  font-weight: 200;
}
.jumbotron > hr {
  border-top-color: #d5d5d5;
}
.container .jumbotron,
.container-fluid .jumbotron {
  border-radius: 6px;
}
.jumbotron .container {
  max-width: 100%;
}
.jumbotron h4 {
    margin-left: 25px;
    margin-bottom: 10px;
    margin-top: 10px;
    font-family: Tw Cen Mt;
    color: #ffffff;
}
.lol-button, button, input[type=button], input[type=reset], input[type=submit] {
    border-radius: 0;
    padding: 13px 30px;
    display: inline-block;
    font-family: Montserrat;
    font-size: 11px;
    line-height: 15px;
    color: #fff;
    text-decoration: none;
    border: none;
    background: #303030;
    text-transform: uppercase;
    -webkit-transition: all .2s ease;
    transition: all .2s ease;
}
.container {
    margin-top: 50px;
    margin-bottom: 15px;
    margin: 0px;
    padding: 0px;
    font-family: Tw Cen Mt;
    font-size: 9px;
}
</style>
<?php  
if(is_user_logged_in() ){
	$user_id=get_current_user_id();
	$single = true;
	$displayCount = get_user_meta( $user_id, 'popup_display', $single ); 	
	//if($displayCount==1){
?>
<!-- Button trigger modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <div class="logo" align="center">
<img src="http://www.museumofknowledge.com/wp-content/uploads/2016/12/MOK-logo-low-resolution-VERSION-2.jpg" class="img-responsive" alt="img-rounded" width="344" height="276" align="center">
</div>
      </div>
      <div class="modal-body">
        <form action="#" id="frmaccesscode" method="post" >		
			 <input type="text" name="accesscode" id="accesscode"  placeholder="Enter Access Code">			
			   <div id="error_msg"></div> 	<div id="success_msg"></div>   				 
				 <div class="modal-footer">
			     <input type="submit" name="submit" value="Submit" >
				 <a  class="btn-resend lol-button" href="<?php echo get_home_url(); ?>/resend-accesscode">Resend</a>
				<!-- <input type="reset" name="Resend" value="Resend" class="btn-resend">-->
			 </div>
		</form>
      </div>     
    </div>
  </div>
</div>
<?php //}	 
$popup_value = 2;
$updated = update_user_meta( $user_id, 'popup_display', $popup_value );
$single = true;
$user_last = get_user_meta( $user_id, 'popup_display', $single ); 
?>	
<?php } ?>

