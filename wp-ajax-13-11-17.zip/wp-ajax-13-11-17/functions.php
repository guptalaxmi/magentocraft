<?php
/**
 * Lollum
 * 
 * Theme functions and definitions
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development
 * and http://codex.wordpress.org/Child_Themes), you can override certain
 * functions (those wrapped in a function_exists() call) by defining them first
 * in your child theme's functions.php file. The child theme's functions.php
 * file is included before the parent theme's file, so the child theme
 * functions would be used.
 *
 * @package WordPress
 * @subpackage Lollum Themes
 * @author Lollum <support@lollum.com>
 *
 */

/**
 * Tell WordPress to run lollum_setup() when the 'after_setup_theme' hook is run.
 */
if ( ! function_exists( 'lollum_setup' ) ) {
	function lollum_setup() {

		/* Make the theme available for translation.
		*  Translations can be added to the /languages/ directory.
		*/
		load_theme_textdomain( 'lollum', get_template_directory() . '/languages' );

		$locale = get_locale();
		$locale_file = get_template_directory() . "/languages/$locale.php";
		if ( is_readable( $locale_file ) ) {
		  require_once( $locale_file );
		}

		// Register the wp 3.0 Menus.
		register_nav_menu( 'primary', esc_html__( 'Menu', 'lollum' ) );
		register_nav_menu( 'mobile', esc_html__( 'Mobile', 'lollum' ) );
		register_nav_menu( 'footer', esc_html__( 'Footer', 'lollum' ) );

		// Add support for Post Formats
		add_theme_support( 'post-formats', array( 'aside', 'status', 'quote', 'image', 'gallery', 'video', 'audio', 'link' ) );

		// Add post thumbnails support
		add_theme_support( 'post-thumbnails' );
		add_image_size( 'widget-thumb', 150, 150, true ); // Widget thumbnails
		add_image_size( 'post-thumb', 848, 537, true ); // Post thumbnails
		add_image_size( 'page-thumb', 9999, 9999, false ); // Page thumbnails
		add_image_size( 'project-thumb', 1140, 570, true ); // Single project thumbnails
		add_image_size( 'featured-thumb', 720, 482, true ); // Featured thumbnails (blocks)
		add_image_size( 'carousel-thumb', 424, 537, true ); // Carousel thumbnails
		add_image_size( 'masonry-thumb', 720 ); // Masonry thumbnails

		if ( ! isset( $content_width ) ) {
		  $content_width = 870;
		}

		add_theme_support( 'automatic-feed-links' );

		add_theme_support( 'woocommerce' );

		$features = array(
			'Column' => 'yes',
			'Divider' => 'yes',
			'Space' => 'yes',
			'Line' => 'yes',
			'Heading' => 'yes',
			'Heading-Small' => 'yes',
			'Section-Title' => 'yes',
			'Image' => 'yes',
			'Carousel-Images' => 'yes',
			'Masonry-Images' => 'yes',
			'Service-Column' => 'yes',
			'Mini-Service-Column' => 'yes',
			'Embed-Video' => 'yes',
			'Block-Text-Banner-Alt' => 'yes',
			'Block-Image-Banner' => 'yes',
			'Post' => 'yes',
			'Blog-Full' => 'yes',
			'Blog-List' => 'yes',
			'Project' => 'yes',
			'Portfolio-Full' => 'yes',
			'Portfolio-List' => 'yes',
			'Masonry-Projects' => 'yes',
			'Masonry-Products' => 'yes',
			'Carousel-Projects' => 'yes',
			'Carousel-Product-Categories' => 'yes',
			'Carousel-Products' => 'yes',
			'Member' => 'yes',
			'Progress-Circle' => 'yes',
			'Progress-Number' => 'yes',
			'Testimonials' => 'yes',
			'Toggle' => 'yes',
			'FAQs' => 'yes',
			'Job-List' => 'yes',
			'Map' => 'yes',
			'Full-Map' => 'yes',
			'Call-To-Action' => 'yes',
			'Newsletter' => 'yes',
			'Section-Open' => 'yes',
			'Section-Close' => 'yes'
		);
		$post_types = array(
			'portfolio' => 'yes',
			'team' => 'yes',
			'job' => 'yes',
			'faq' => 'yes',
			'testimonials' => 'yes'
		);
		add_option( 'lolfmk_supported_post_types', $post_types );
		add_option( 'lolfmk_supported_features', $features );
		add_option( 'lolfmk_support_page_builder', 'yes' );
		add_option( 'lolfmk_load_shortcodes_scripts', 'no' );
		add_option( 'lolfmk_margin_full', 'yes' );
		add_option( 'lolfmk_template_portfolio', 'yes' );
		add_option( 'lolfmk_template_portfolio_masonry', 'yes' );
		add_option( 'lolfmk_portfolio_video_lightbox', 'yes' );
		add_option( 'lolfmk_transparent_header', 'yes' );
		add_option( 'lolfmk_custom_woo_shortcodes', 'yes' );
	}
}
add_action( 'after_setup_theme', 'lollum_setup' );

if( ! function_exists( 'lolfmk_remove_supported_features' ) ) {
	function lolfmk_remove_supported_features() {
		delete_option( 'lolfmk_supported_features'  );
		delete_option( 'lolfmk_support_page_builder');
		delete_option( 'lolfmk_load_shortcodes_scripts' );
		delete_option( 'lolfmk_supported_post_types' );
		delete_option( 'lolfmk_margin_full' );
		delete_option( 'lolfmk_template_portfolio' );
		delete_option( 'lolfmk_template_portfolio_masonry' );
		delete_option( 'lolfmk_portfolio_video_lightbox' );
		delete_option( 'lolfmk_transparent_header' );
		delete_option( 'lolfmk_custom_woo_shortcodes' );
	}
}
add_action( 'switch_theme', 'lolfmk_remove_supported_features' );

/**
 * Load up core options
 */

require_once( get_template_directory() . '/core/core.php' );

/**
 * Register general scripts
 */

add_action( 'wp_enqueue_scripts', 'lollum_register_js' );
if ( ! function_exists( 'lollum_register_js' ) ) {
	function lollum_register_js() {
		if ( ! is_admin() ) {
			wp_register_script( 'nantes-modernizr', LOLLUM_URI . '/js/modernizr.js', array(), '', 0 );
			wp_register_script( 'nantes-common', LOLLUM_URI . '/js/common.js', array( 'jquery' ), '', 1 );
			wp_register_script( 'nantes-isotope', LOLLUM_URI . '/js/jquery.isotope.js', array( 'jquery' ), '', 1 );
			wp_register_script( 'nantes-parallax', LOLLUM_URI . '/js/jquery.parallax.js', array( 'jquery' ), '', 1 );
			wp_register_script( 'nantes-countTo', LOLLUM_URI . '/js/jquery.countTo.js', array( 'jquery' ), '', 1 );
			wp_register_script( 'nantes-easypiechart', LOLLUM_URI . '/js/jquery.easypiechart.js', array( 'jquery' ), '', 1 );
			wp_register_script( 'nantes-carousel', LOLLUM_URI . '/js/owl-carousel.js', array( 'jquery' ), '', 1 );
			wp_register_script( 'nantes-init', LOLLUM_URI . '/js/init.js', array( 'jquery' ), '', 1 );
			wp_register_script( 'lolfmk-progress', LOLLUM_URI . '/js/progress-circle.js', array( 'jquery', 'nantes-easypiechart' ), '', 1 );

			wp_localize_script( 'lolfmk-progress', 'lolfmk_progress_vars', 
				array(
					'barColor' => esc_js( get_option( 'lol_ac_color' ) )
				)
			);

			if ( lollum_check_is_woocommerce() && is_product() && ( get_option( 'lol_check_custom_rating_system' ) === 'true' ) ) {

				wp_enqueue_script('ratings-js', LOLLUM_URI . '/woocommerce/js/ratings.js', array('jquery'), '', 1 );

				wp_localize_script( 'ratings-js', 'lollum_view_ratings_vars', 
					array( 
						'ajaxurl' => admin_url( 'admin-ajax.php' ),
						'nonce' => wp_create_nonce('lollum-rating-nonce')
					) 
				);

			}

			if ( lollum_check_is_woocommerce() && is_account_page() ) {

				wp_register_script('login-js', LOLLUM_URI . '/woocommerce/js/login.js', array('jquery'), '', 1 );

				wp_enqueue_script( 'login-js' );

			}
			
			wp_enqueue_script( 'nantes-modernizr' );
			wp_enqueue_script( 'nantes-common' );
			wp_enqueue_script( 'nantes-init' );
		}
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) && ! is_page() ) {
			wp_register_script( 'lollum-comment-reply', LOLLUM_URI . '/js/comment-reply.min.js', '', 1 );
			wp_enqueue_script( 'lollum-comment-reply' );
		}
	}
}

/**
 * Register general styles
 */

if ( ! function_exists( 'lollum_register_css' ) ) {
	function lollum_register_css() {
		if ( ! is_admin() ) {
			global $wp_styles;
			wp_register_style( 'grid-css', LOLLUM_URI . '/css/grid.css', array(), '' );
			wp_register_style( 'fonts', LOLLUM_URI . '/css/fonts.css', array(), '' );
			wp_register_style( 'nantes-default', get_stylesheet_uri(), '' );
			wp_register_style( 'nantes-css', LOLLUM_URI . '/css/base.css', array(), '' );
			if ( lollum_check_is_woocommerce() ) {
				wp_register_style( 'woocommerce-css', LOLLUM_URI . '/woocommerce/css/woocommerce.css', array(), '' );
			}
			if ( get_option( 'lol_check_responsive' ) != 'true' ) {
				wp_register_style( 'no-responsive-css', LOLLUM_URI . '/css/base-nr.css', array(), '' );
				wp_register_style( 'woo-no-responsive-css', LOLLUM_URI . '/woocommerce/css/woocommerce-nr.css', array(), '' );
			}
			wp_register_style( 'ie8-css', LOLLUM_URI . '/css/ie8.css', array(), '' );
			wp_register_style( 'nantes-custom', LOLLUM_URI . '/css/custom.css', array(), '' );

			wp_enqueue_style( 'grid-css' );
			wp_enqueue_style( 'fonts' );

			wp_enqueue_style( 'nantes-default' );
			wp_enqueue_style( 'nantes-css' );
			if ( lollum_check_is_woocommerce() ) {
				wp_enqueue_style( 'woocommerce-css' );
			}
			if ( get_option( 'lol_check_responsive' ) != 'true' ) {
				wp_enqueue_style( 'no-responsive-css' );
			}
			if ( ( get_option('lol_check_responsive' ) != 'true' ) && lollum_check_is_woocommerce() ) {
				wp_enqueue_style( 'woo-no-responsive-css' );
			}
			wp_enqueue_style( 'nantes-custom' );

			wp_enqueue_style( 'ie8-css' );
			$wp_styles->add_data( 'ie8-css', 'conditional', 'lt IE 9' );
		}

		if ( class_exists( 'YITH_WCWL_UI' ) )  {

			wp_deregister_style( 'yith-wcwl-font-awesome' );
			wp_deregister_style( 'yith-wcwl-font-awesome-ie7' );

		}
		
	}
}
add_action( 'wp_enqueue_scripts', 'lollum_register_css' );


/**
 * Queue frontend scripts/styles.
 */

if ( ! function_exists( 'lollum_queue_frontend' ) ) {
	function lollum_queue_frontend() {
		if ( is_page() ) {
			wp_enqueue_script( 'nantes-parallax' );
		}
		if ( is_page() || ( 'lolfmk-portfolio' == get_post_type() ) ) {
			wp_enqueue_style( 'lolfmk-prettyPhoto-css' );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'lollum_queue_frontend' );

/**
* Access Code Generation
*
**/



add_action('woocommerce_thankyou', 'accesscode_mail_send', 10, 1);
function accesscode_mail_send( $order_id ) {
     $order = wc_get_order( $order_id );
	 $customerEmail = $order->billing_email;	
	 $fName= $order->billing_first_name;
	 $lName= $order->billing_last_name;
	 $fullName= $fName.''.$lName;
	
	 $currentDate=date('d/m/Y');
	 $currency = get_woocommerce_currency_symbol();
	 /*Email Template*/
	
  $message = "<html><head><title>Your Museum Of Knowledge order receipt</title></head><body><div style='padding-left: 9%;'><img src='http://www.museumofknowledge.com/wp-content/uploads/2017/11/newlogo.jpg'/></div><div style='
    text-align: center;'><img src='http://www.museumofknowledge.com/wp-content/uploads/2017/11/img1-1024x640-1.jpg' /></div></div>";
 $message .= "<h1 style='text-align:center;'> PURCHASE SUMMARY ACCESS CODE</h1>";
	
	
	
   $message .= "<table style='border: 1px solid black;margin: 0 auto;border-collapse: collapse;'><tr style='border: 1px solid black;'><td style='border: 1px solid black;padding: 10px 41px;'><b>Customer ID</b></td><td style='border: 1px solid black;padding: 10px 41px;'><table style='border-collapse: collapse;'><tr><td style='border: 1px solid black;padding: 10px 41px;'><b>".$fullName."</b></td><td style='border: 1px solid black;padding: 10px 41px;'><b>".$customerEmail."</b></td></tr></table></td></tr>";
	foreach ( $order->get_items()  as $item_id => $item  ) {
		$productId=$item['product_id'];
		$productName=$item['name'];
		$price = wc_format_decimal( $order->get_line_subtotal( $item ), 2 );		
		$itemTotal= wc_format_decimal( $order->get_item_total( $item ), 2 );		
		$accesstoken = bin2hex(random_bytes(4));
		$message .=	"<tr style='border: 1px solid black;'><td style='border: 1px solid black;padding: 10px 41px;'><b>Item</b></td><td style='border: 1px solid black;padding: 10px 41px;'><b>".$productName."</b></td></tr>";
		$message .=	"<tr style='border: 1px solid black;'><td style='border: 1px solid black; padding: 10px 41px;'><b>Access Code</b></td><td style='border: 1px solid black;padding: 10px 41px;'><b>".$accesstoken."</b></td></tr>";
		$message .=	"<tr style='border: 1px solid black;'><td style='border: 1px solid black;padding: 10px 41px;padding: 10px 41px;'><b>Access Code Duration</b></td><td style='border: 1px solid black;padding: 10px 41px;'></td></tr>";
		$message .="<tr style='border: 1px solid black;'><td style='border: 1px solid black;padding: 10px 41px;'><b>Access Code Dates</b></td><td style='border: 1px solid black;padding: 10px 41px;'><b>".$currentDate."-</b></td></tr>";
		$message .=	"<tr style='border: 1px solid black;'><td style='border: 1px solid black;padding: 10px 41px;'><b>Price</b></td><td style='border: 1px solid black;padding: 10px 41px;'><b>".$currency.$itemTotal."</td></td></tr>";
		/*Set access code in database*/		
		global $wpdb;		
		$table_name="wp_woocommerce_order_items";
		$wpdb->query("UPDATE $table_name SET access_code = '$accesstoken' WHERE order_id = $order_id and order_item_name = '$productName'");
	   /*Set access code in database*/	
    }
	/*Mail Send*/
     $message .="</table></body></html>";	
	$subject = 'Museum Of Knowledge Order Access Code';	
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "From: Museum Of Knowledge\r\n";
    $headers = array('Content-Type: text/html; charset=UTF-8');
    wp_mail( $customerEmail, $subject, $message,$headers );
}









/**
* Access Code Popup
*
**/
add_action( 'wp_ajax_check_accesscode', 'check_accesscode' );
add_action('wp_ajax_nopriv_check_accesscode','check_accesscode');
function check_accesscode(){
	$customerOrderEmail="";	
	$currentUserEmail="";
	$status=0;
	
	$str = $_POST['codeData'];	
	parse_str($str, $data);	
	$code= $data['accesscode'];
	$current_user = wp_get_current_user();
    $currentUserEmail = $current_user->user_email;	
	
	global $wpdb;		
	$table_name="wp_woocommerce_order_items";
	$resultData = $wpdb->get_row("Select * FROM $table_name  WHERE access_code = '$code'");
	$orderId= $resultData->order_id;
	if(!empty(orderId)){		
		$resultStatus=1;
	$orderItemId= $resultData->order_item_id;
	$orderItemName= $resultData->order_item_name;	
	$order = wc_get_order( $orderId );
	$customerOrderEmail = $order->billing_email;

 	 if($customerOrderEmail == $currentUserEmail){
		$status=1;
			$items = $order->get_items();
			foreach ( $items as $item ) {
				//if($orderId== $item['order_id']){       
				 $linkurl = get_permalink( $item['product_id'] ) ;
			   //}
			}
	  }
	}
	if($status==1){		
		echo json_encode(array('status'=>'1','url'=>$linkurl));		
	}else{
		$url="";
		echo json_encode(array('status'=>'0','url'=>$linkurl));	
	}
	die;
//	wp_die(); terminate immediately and return a proper response
}


add_action( 'wp_login', 'login_popup' );
function login_popup( $user_login ) {
   $popup_value = 1;
   $user_id=get_current_user_id();
    $updated = update_user_meta( $user_id, 'popup_display', $popup_value );
}

add_action( 'wp_logout', 'login_popup' );
function logout_popup( $logout_popup ) {
   $popup_value = 0;
   $user_id=get_current_user_id();
    $updated = update_user_meta( $user_id, 'popup_display', $popup_value );
}





/**
*Resend Access Code Popup
*
**/
add_action( 'wp_ajax_resend_accesscode', 'resend_accesscode' );
add_action('wp_ajax_nopriv_resend_accesscode','resend_accesscode');
function resend_accesscode()
{	
    $resultMessage="Enter Details is correct"; $status=1;	
    $str = $_POST['codeData'];	
	parse_str($str, $data);	
	$email= $data['email'];
	$password= $data['password'];

	global $wpdb;		
	$table_name="wp_users";
	$userdata = $wpdb->get_row("Select * FROM $table_name  WHERE user_email LIKE '$email'");
	$custumorID= $userdata->ID;
	$password_hashed= $userdata->user_pass;
    
	if(empty($custumorID )) {
	   $resultMessage='User email details not correct';
			echo json_encode(array('status'=>'0','message'=>$resultMessage));
			die;
	}	
    if(wp_check_password( $password, $password_hashed, $user_id = $custumorID )) {
    } 
    else {
           $resultMessage='User password details not correct';
			echo json_encode(array('status'=>'0','message'=>$resultMessage));
			die;
    }
	$order_statuses = array('wc-on-hold', 'wc-processing', 'wc-completed');	
    $customer_orders = get_posts( array(
        'numberposts' => -1,
        'meta_key'    => '_customer_user',
        'meta_value'  => $custumorID,
        'post_type'   => wc_get_order_types(),
        'post_status' =>$order_statuses ,
    ) );
    if (count($customer_orders)>=1) {		  
			$message = "<html><head><title>Your Museum Of Knowledge order receipt</title></head><body><div style='padding-left: 9%;'><img src='http://www.museumofknowledge.com/wp-content/uploads/2017/11/newlogo.jpg'/></div><div style='
				text-align: center;'><img src='http://www.museumofknowledge.com/wp-content/uploads/2017/11/img1-1024x640-1.jpg' /></div></div>";
			 $message .= "<h1 style='text-align:center;'> PURCHASE SUMMARY ACCESS CODE</h1>";
			 $message .= "<body><table>"; 
		    
			foreach ( $customer_orders as $customer_order ){
				  $order_id= $customer_order->ID;
				  $message .=	"<tr><td><b>Order Id</b></td><td>".$order_id."</td></tr>";	
				  global $wpdb;		
				  $table_name="wp_woocommerce_order_items";
				  $resultData = $wpdb->get_results("Select * FROM $table_name  WHERE order_id = '$order_id'");
				  
			    foreach ( $resultData as $item ) {
					  $productName =  $item->order_item_name;
					  $accessCode =  $item->access_code;
				      $message .=	"<tr><td>Product Name</td><td>".$productName."</td></tr>";
				      $message .=	"<tr><td>Access Code</td><td>".$accessCode."</td></tr>";	
			     }
		    }
		    $message .="</table></body></html>";
            // $resultMessage='User email details not correct';
			echo json_encode(array('status'=>'1','message'=>$message));
			die;		  
	}else{
		$message ="no access code found";
		echo json_encode(array('status'=>'0','message'=>$message));
		die;
	}		
}

