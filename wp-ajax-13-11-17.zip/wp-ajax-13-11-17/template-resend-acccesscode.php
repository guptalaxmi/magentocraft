<?php
/**
 * Lollum
 * 
 * The Template for displaying pages with sidebar right
 *
 * @package WordPress
 * @subpackage Lollum Themes
 * @author Lollum <support@lollum.com>
 *
 */
/*
Template Name: Resend AccessCode Template
*/
?>
<?php 

get_header(); 


/*
$password_hashed = '$P$BLibNU5aXriTxqvVP3xETCpgeIcp5o0';
$plain_password = 'p@ssw0rd11112';
if(wp_check_password( $plain_password, $password_hashed, $user_id = '200010' )) {
    echo "YES, Matched";
} else {
    echo "No, Wrong Password";
}


 $user_id = 200011; // current user ID here for example 
 $order_statuses = array('wc-on-hold', 'wc-processing', 'wc-completed');	
 $customer_orders = get_posts( array(
        'numberposts' => -1,
        'meta_key'    => '_customer_user',
        'meta_value'  => $user_id,
        'post_type'   => wc_get_order_types(),
        'post_status' =>$order_statuses ,
    ) );
    if (count($customer_orders)>=1) {		  
			$message = "<html><head><title>Your Museum Of Knowledge order receipt</title></head><body><div style='padding-left: 9%;'><img src='http://www.museumofknowledge.com/wp-content/uploads/2017/11/newlogo.jpg'/></div><div style='
				text-align: center;'><img src='http://www.museumofknowledge.com/wp-content/uploads/2017/11/img1-1024x640-1.jpg' /></div></div>";
			 $message .= "<h1 style='text-align:center;'> PURCHASE SUMMARY ACCESS CODE</h1>";
			 $message .= "<body><table>"; 
		  foreach ( $customer_orders as $customer_order ){
			  $order_id= $customer_order->ID;
			  $message .=	"<tr><td><b>Order Id</b></td><td>".$order_id."</td></tr>";	
			  global $wpdb;		
	          $table_name="wp_woocommerce_order_items";
	  	      $resultData = $wpdb->get_results("Select * FROM $table_name  WHERE order_id = '$order_id'");
	          
			  foreach ( $resultData as $item ) {
					  $productName =  $item->order_item_name;
					  $accessCode =  $item->access_code;
				      $message .=	"<tr><td>Product Name</td><td>".$productName."</td></tr>";
				      $message .=	"<tr><td>Access Code</td><td>".$accessCode."</td></tr>";	
			  }
		  }
		  echo  $message .="</table></body></html>";	
	}
*/	
?>


<div class="container">
<div class="row">
<div class="lm-col-12 lol-page-item">
	
<script>
jQuery(document).ready(function(){
	

	
jQuery("form#frmaccesscode").submit(function(){
	jQuery("#success_msg").html('');
	jQuery("#feedback_msg1").html('');
		if(jQuery("#email").val()==''){
			jQuery("#error_msg").html("<span style='color:red'>Please Enter Email.</span>");
			//alert("Please enter Access Code");
			return false;
		}
		
		if(jQuery("#email").val()!=''){
			   var sEmail=jQuery("#email").val();
			   var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
	       
		   if (filter.test(sEmail)) {
		    }else{
			    jQuery("#error_msg").html("<span style='color:red'>Please Enter Valid Email.</span>");
			    return false;
			}
		}
		if(jQuery("#password").val()==''){
			jQuery("#error_msg").html("<span style='color:red'>Please Enter Password.</span>");
			return false;
		}
		
		
		var data = {
			'action': 'resend_accesscode',
			'codeData': jQuery("#frmaccesscode").serialize()
		};
		jQuery.ajax({
			type: "post",
			dataType: "json",
			url: "<?php echo admin_url('admin-ajax.php'); ?>",
			data: data,
			success: function(msg){
				
				var resultMsg=msg.message;
				
				if(msg.status=='1'){	
					
                    jQuery("#error_msg").html(resultMsg);
					jQuery("#error_msg").show();
					jQuery("#frmaccesscode input[type=text],#frmaccesscode textarea").val('');					
					// setTimeout(function(){window.location.href= urlData; } , 1000);
					
				}else{			
					
                    jQuery("#error_msg").html(resultMsg);
					jQuery("#error_msg").show();	
					
				}
			}
		});
		return false;
	});
	
	jQuery( "a#close" ).click(function() {    
       jQuery('#popup').css("visibility", "hidden"); 
       jQuery('#popup').css("opacity", 0);
    });
	});
</script>

<!-- Popup -->


<?php  
//if(is_user_logged_in() ){
	//$user_id=get_current_user_id();
	//$single = true;
	//$displayCount = get_user_meta( $user_id, 'popup_display', $single ); 
	
	//if($displayCount==1){
?>
<!-- Button trigger modal -->

      <div class="modal-body1">
        <form action="#" id="frmaccesscode" method="post" >		
			  <input type="text" name="email" id="email"  placeholder="Enter Email">	
              <input type="text" name="password" id="password"  placeholder="Enter Password">			
						 
			   <div id="error_msg"></div> 	<div id="success_msg"></div>   				 
				 <div class="modal-footer">
			     <input type="submit" name="submit" value="Submit" >
			  </div>
		</form>
      </div>     
   
<?php //}	 

//$popup_value = 2;
//$updated = update_user_meta( $user_id, 'popup_display', $popup_value );
//$single = true;
//$user_last = get_user_meta( $user_id, 'popup_display', $single ); 
?>	

<?php //} ?>
</div>
</div>
</div>
<?php get_footer(); ?>
