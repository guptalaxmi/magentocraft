require(["jquery"], function($j){
   // alert("my name");
	
	
	/*$j('#loopedSlider').loopedSlider({
				autoStart: 5000,
				restart: 7000
			});
	*/		
	 
});

