<?php
namespace Oss\Cartevent\Observer;

class Customprice implements \Magento\Framework\Event\ObserverInterface
{
  public function execute(\Magento\Framework\Event\Observer $observer)
  {   
    
    /*Set default Product price to cart item quote*/	
	/*  $item = $observer->getEvent()->getData('quote_item');         
		$item = ( $item->getParentItem() ? $item->getParentItem() : $item );
		$price = 100; 
		$item->setCustomPrice($price);
		$item->setOriginalCustomPrice($price);
		$item->getProduct()->setIsSuperMode(true); 
	*/
	
  }
  
}