<?php
    /**
     * Syn Rewrite Product ListProduct Block
     *
     * @category    Webkul
     * @package     Webkul_Hello
     * @author      Webkul Software Private Limited
     *
     */
    namespace Oss\Syn\Block\Rewrite\Product;
 
    class ListProduct extends \Magento\Catalog\Block\Product\ListProduct
    {
        public function _getProductCollection()
        {
            // Do your stuff here
        }
    }
	