<?php
/*
 * Synapseindia_Urlrewriteimporter

 * @category   Synapseindia
 * @package    Synapseindia_Urlrewriteimporter
 * @copyright  Copyright (c) 2017 Synapseindia
 * @license    Synapseindia
 * @version    1.0.0
 */
namespace Synapseindia\Urlrewriteimporter\Block\Adminhtml\Urlrewrite\Edit;

use Magento\Backend\Block\Widget\Form\Generic;

class Form extends Generic
{
    /**
     * Prepare form attributes
     * @return \Magento\Backend\Block\Widget\Form
     * @codingStandardsIgnoreStart
     */
    protected function _prepareForm()
    {
        // @codingStandardsIgnoreEnd
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            [
                'data' => [
                    'id'    => 'edit_form',
                    'enctype' => 'multipart/form-data',
                    'action' => $this->getUrl('*/*/importAction'),
                    'method' => 'post'
                ]
            ]
        );
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}
